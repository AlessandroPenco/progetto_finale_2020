package lab11_05_11.visitors.typechecking;

public enum PrimtType implements Type {
	BOOL, INT;
}
