package lab11_05_11.parser.ast;

public interface Stmt extends AST {
}
