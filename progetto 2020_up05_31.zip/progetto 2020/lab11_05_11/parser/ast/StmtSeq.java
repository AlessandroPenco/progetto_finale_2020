package lab11_05_11.parser.ast;

public interface StmtSeq extends AST {
}
